package com.salmon.test.pageobjects;

import com.salmon.test.framework.PageObject;
import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HomePage extends PageObject {
    protected static final Logger LOG = LoggerFactory.getLogger(HomePage.class);

    private  By headerSignInLink = By.id("headerSignInLink");


    public void clickSignInLink(){
        waitForExpectedElement(headerSignInLink).click();
    }

}
