package com.salmon.test.pageobjects;

import com.salmon.test.framework.PageObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class RegistrationPage extends PageObject {
    protected static final Logger LOG = LoggerFactory.getLogger(RegistrationPage.class);

    private static final By byScrapbookLinkId = By.id("scrapbook");


    private WebElement addressOrLocationText() {
        return waitForExpectedElement(byScrapbookLinkId);
    }

//
//    @PostConstruct
//    public void waitForProductCategoryPageIsFullyLoaded() {
//        waitForDeco();
//    }
//
//


    @FindBy(id = "text")
    private WebElement searchField;




    private WebElement storeFinderHeading() {
        return waitForExpectedElement(By.className("title-text"));
    }

    private List<WebElement> storeFinderIntroductoryText() {
        return webDriver.findElements(By.className("intro-text"));
    }

    private WebElement storeFinderSearchTermResultsGridHeading() {
        return waitForExpectedElement(By.xpath(".//*[@id='store-results']/h3/em"));
    }
}
