Salmon Test Automation Framework
================================

To run, you will need to install maven, then:

mvn clean install -P profile

A report will be generated at /target/cucumber-report/index.html
